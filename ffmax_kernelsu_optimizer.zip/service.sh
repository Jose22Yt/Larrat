#!/system/bin/sh

# Este script se ejecuta como un servicio en segundo plano por KernelSU Next.
# Monitorea el estado de Free Fire Max y ajusta la resolución/DPI dinámicamente.

MODDIR=${0%/*}

log_print() {
  echo "FFMAX_OPTIMIZER_SERVICE: $1"
}

PACKAGE_NAME="com.dts.freefiremax"
TARGET_RESOLUTION_GAME="1440x3200"
TARGET_DPI_GAME="897"

# Resolución a aplicar cuando el juego NO está activo
DEFAULT_RESOLUTION_RESTORE="1080x2400"

log_print "🚀 Iniciando servicio de monitoreo para Free Fire Max..."

log_print "⏳ Esperando que Free Fire Max se inicie..."

GAME_ACTIVE=false

while true; do
    # Verificar si Free Fire Max está en primer plano
    if dumpsys activity activities | grep -q "$PACKAGE_NAME"; then
        if [ "$GAME_ACTIVE" = false ]; then
            log_print "🔥 Free Fire Max detectado. Aplicando configuración de juego (Resolución: $TARGET_RESOLUTION_GAME, DPI: $TARGET_DPI_GAME)..."
            wm size "$TARGET_RESOLUTION_GAME"
            wm density "$TARGET_DPI_GAME" # wm density es el comando para ajustar el DPI
            GAME_ACTIVE=true
            log_print "✅ Configuración de juego aplicada con éxito."
        fi
    else
        if [ "$GAME_ACTIVE" = true ]; then
            log_print "❄️ Free Fire Max cerrado. Restaurando configuración del sistema (Resolución: $DEFAULT_RESOLUTION_RESTORE, DPI por defecto)..."
            wm size "$DEFAULT_RESOLUTION_RESTORE"
            wm density reset # Restaurar DPI a la configuración por defecto del sistema
            GAME_ACTIVE=false
            log_print "✅ Configuración restaurada a $DEFAULT_RESOLUTION_RESTORE y DPI por defecto."
            log_print "💤 Monitoreo en pausa hasta el próximo inicio del juego..."
        fi
    fi
    sleep 5 # Esperar 5 segundos antes de volver a verificar
done
