#!/system/bin/sh

# Este script se ejecuta como un servicio en segundo plano por KernelSU Next.
# Monitorea el estado de Free Fire Max y ajusta la resolución/DPI dinámicamente.

MODDIR=${0%/*}

log_print() {
  echo "FFMAX_OPTIMIZER_SERVICE: $1"
}

PACKAGE_NAME="com.dts.freefiremax"
TARGET_RESOLUTION="1440x3200"
TARGET_DPI="897" # Usamos DPI en lugar de Density para claridad, pero el comando es wm density

log_print "🚀 Iniciando servicio de monitoreo para Free Fire Max..."

# No necesitamos capturar la resolución y densidad originales si vamos a usar 'reset'
# Sin embargo, es buena práctica tener un valor por defecto si 'reset' falla o no es deseado en algún caso.
# Para este caso, el usuario ha solicitado explícitamente 'reset'.

log_print "⏳ Esperando que Free Fire Max se inicie..."

GAME_ACTIVE=false

while true; do
    # Verificar si Free Fire Max está en primer plano
    if dumpsys activity activities | grep -q "$PACKAGE_NAME"; then
        if [ "$GAME_ACTIVE" = false ]; then
            log_print "🔥 Free Fire Max detectado. Aplicando configuración de juego (Resolución: $TARGET_RESOLUTION, DPI: $TARGET_DPI)..."
            wm size "$TARGET_RESOLUTION"
            wm density "$TARGET_DPI" # wm density es el comando para ajustar el DPI
            GAME_ACTIVE=true
            log_print "✅ Configuración de juego aplicada con éxito."
        fi
    else
        if [ "$GAME_ACTIVE" = true ]; then
            log_print "❄️ Free Fire Max cerrado. Restaurando configuración original del sistema..."
            wm size reset
            wm density reset
            GAME_ACTIVE=false
            log_print "✅ Configuración original restaurada."
            log_print "💤 Monitoreo en pausa hasta el próximo inicio del juego..."
        fi
    fi
    sleep 5 # Esperar 5 segundos antes de volver a verificar
done
